import model.Activities;
import model.Card;
import model.MessageType;
import model.Player;
import model.Regions;
import java.util.*;
import java.io.*;
import java.util.concurrent.*;

public class BoomerangAustralia {

    public final List<Player> players = new ArrayList<>();
    private final GameServer gameServer = new GameServer();
    private static final int CARDS_PER_HAND = 7;
    private static final int DRAFTING_TURNS = CARDS_PER_HAND - 1;
    private static final int NUMBER_OF_ROUNDS = 4;

    //TODO EU
    //private final RuleSet ruleSet;


    public static void main(String[] args) {

        if (args.length == 0) { // connect to local host as a guest client
            new GameClient().run("127.0.0.1");
            return;
        }

        if (args.length == 1) { // connect to IP as a guest client
            new GameClient().run(args[0]);
            return;
        }

        if (args.length > 2) {
            System.out.println("""
            This game requires 2-4 players/bots.

            Host:   java BoomerangAustralia numPlayers numBots
            Join:   java BoomerangAustralia [IP]
            """);
            return;
        }

        try {
            int numPlayers = Integer.parseInt(args[0]);
            int numBots = Integer.parseInt(args[1]);

            if (numPlayers < 1 || numBots < 0 || numPlayers + numBots < 2 || numPlayers + numBots > 4) {
                System.out.println("This game requires 2-4 players/bots");
                return;
            }

            new BoomerangAustralia().hostGame(numPlayers, numBots);

        } catch (NumberFormatException _) {
            System.err.println("Player counts must be valid integers.");
        }
    }

    private void hostGame(int numPlayers, int numBots) {
        CountDownLatch serverReady = new CountDownLatch(1);

        new Thread(() -> runGame(numPlayers, numBots, serverReady)).start();

        try {
            serverReady.await();
            new GameClient().run("127.0.0.1"); // Host joins as a client when the server is ready
        } catch (InterruptedException _) {
            Thread.currentThread().interrupt();
        }
    }

    private void addCardToDraft(Player player, Player sendToPlayer) {
        showDraftingOptions(player);
        String response = chooseCard(player);
        player.draftCard(response);

        sendToPlayer.getNextHand().clear();
        //pass my hand to the next player
        sendToPlayer.getNextHand().addAll(player.getHand());
    }

    private void showDraftingOptions(Player player) {
        // Print the list of cards in the draft
        if (player.getDraft().isEmpty()) {
            gameServer.sendMessage(player, MessageType.DISPLAY_MESSAGE, "You haven't drafted any cards yet");
        } else {
            gameServer.sendMessage(player, MessageType.DISPLAY_MESSAGE, "%n********************************%nYour current draft: %n%s"
                    .formatted(GameFormatter.formatCards(player.getDraft())));
        }

        if (!player.getSites().isEmpty()) {
            StringBuilder sb = new StringBuilder("Sites from previous rounds:\n");

            for (Map.Entry<String, String> site : player.getSites().entrySet()) {
                sb.append("[").append(site.getKey()).append("] ");
                sb.append(site.getValue()).append("\n");
            }

            gameServer.sendMessage(player, MessageType.DISPLAY_MESSAGE, sb.toString());
        }

        // Print the list of cards in the hand
        gameServer.sendMessage(player, MessageType.DISPLAY_MESSAGE, "%nYour current hand: %n%s"
                .formatted(GameFormatter.formatCards(player.getHand())));
    }

    @SuppressWarnings("java:S2245")
    private String chooseCard(Player player) {
        if (player.isBot()) {
            return player.getHand()
                    .get(ThreadLocalRandom.current().nextInt(player.getHand().size()))
                    .selectionLetter();
        }

        while (true) {
            gameServer.sendMessage(player, MessageType.REQUEST_INPUT, "Type the letter of the card to draft");
            String response = gameServer.readMessage(player);

            for (Card card : player.getHand()) {
                if (card.selectionLetter().equalsIgnoreCase(response)) {
                    return response;
                }
            }

            gameServer.sendMessage(player, MessageType.DISPLAY_MESSAGE, "Invalid card. Choose a card from your hand.");
        }
    }


    private void scoreRound(Player player) {
        HashMap<String, Integer> score = new HashMap<>();

        //Requirement 10a
        int throwCatchScore = ScoreCalculator.calculateThrowCatchScore(player.getDraft());

        gameServer.sendMessage(player, MessageType.DISPLAY_MESSAGE, "This round you scored %d as your Throw and catch score".formatted(throwCatchScore));
        score.put("Throw and Catch score", throwCatchScore);

        //Requirement 10b
        int thisRoundSites = player.countNewSites();
        gameServer.sendMessage(player, MessageType.DISPLAY_MESSAGE, "This round you scored %d new sites points and %d points for completing regions"
                .formatted(thisRoundSites, player.getRegionRoundScore()));
        score.put("Tourist sites score", thisRoundSites);

        //Requirement 10c - Calculate score for CollectionTypes
        int countRoundCollections = ScoreCalculator.calculateCollectionScore(player.getDraft());
        gameServer.sendMessage(player, MessageType.DISPLAY_MESSAGE, "This round you scored %d collection points".formatted(countRoundCollections));
        score.put("Collection score", countRoundCollections);

        //Requirement 10d Calculate score for
        int countRoundAnimals = ScoreCalculator.calculateAnimalScore(player.getDraft());
        gameServer.sendMessage(player, MessageType.DISPLAY_MESSAGE, "This round you scored %d animal points".formatted(countRoundAnimals));
        score.put("Animals score", countRoundAnimals);

        //Requirement 10e Calculate score for the Activities if the player wants to score it
        Map<String, Integer> availableActivities = getAvailableActivities(player);

        gameServer.sendMessage(player, MessageType.DISPLAY_MESSAGE, "This round you have gathered the following new activities:");
        gameServer.sendMessage(player, MessageType.DISPLAY_MESSAGE, "%s\nSelect if you wish to score one of them"
                .formatted(GameFormatter.formatActivities(availableActivities)));

        scoreActivities(player, availableActivities);

        player.getRScore().add(score);
        player.setRegionRoundScore(0); //it has been added to the region list, and will be summed up at the end of the 4 rounds.
        //Requirement 11
        int totalScore = ScoreCalculator.calculatePlayerFinalScore(player);
        gameServer.sendMessage(player, MessageType.DISPLAY_MESSAGE, "Your current total score is %d".formatted(totalScore));

    }

    private Map<String, Integer> getAvailableActivities(Player player) {
        Map<String, Integer> newActivitiesMap = new LinkedHashMap<>();

        for (String thisAct : Activities.ALL) { //Requirement 10e(ii)
            if (!player.getActivitiesScore().containsKey(thisAct)) {
                int frequency = ScoreCalculator.countMatchingCards(
                        player.getDraft(), thisAct, Card::activities);

                newActivitiesMap.put(thisAct, frequency);
            }
        }

        return newActivitiesMap;
    }

    private int finalScore(Player player) {
        int totalScore = ScoreCalculator.calculatePlayerFinalScore(player);

        String scoreboard = GameFormatter.formatScore(
                player.getRScore(),
                player.getActivitiesScore(),
                player.getCompletedRegions().size());

        gameServer.sendMessage(player, MessageType.DISPLAY_MESSAGE, scoreboard);

        return totalScore;
    }

    private void scoreActivities(Player player, Map<String, Integer> newActivitiesMap) {
        for (Map.Entry<String, Integer> activity : newActivitiesMap.entrySet()) {
            int activityScore = ScoreCalculator.calculateActivityScore(activity.getValue());

            gameServer.sendMessage(player, MessageType.REQUEST_INPUT, "Want to keep %s(%d) [%d points]? (Y/N)"
                    .formatted(activity.getKey(), activity.getValue(), activityScore));
            String response = player.isBot() ? "Y" : gameServer.readMessage(player);

            if (response.equalsIgnoreCase("Y")) {
                player.getActivitiesScore().put(activity.getKey(), activityScore);
                gameServer.sendMessage(player, MessageType.DISPLAY_MESSAGE, "This round you scored this activity: %s[%d points]"
                        .formatted(activity.getKey(), activityScore));

                return; //Requirement 10e(i) Only one activity can be scored per round
            }
        }
    }

    private List<Player> createBots(int numBots) {
        List<Player> bots = new ArrayList<>();

        for (int i = 0; i < numBots; i++) {
            bots.add(new Player(players.size() + i, true));
        }

        return bots;
    }



    public void runGame(int numPlayers, int numBots, CountDownLatch serverReady) {

        List<String> regions = Regions.ALL;

        Set<String> finishedRegions = new LinkedHashSet<>();

        try {
            List<Card> deck = DeckFactory.createDeck();  //Requirement 2

            Collections.shuffle(deck); //Requirement 3

            gameServer.acceptPlayers(players, numPlayers, serverReady);
            players.addAll(createBots(numBots));

            dealCardsToPlayers(deck);


            //Requirement 4
            //Requirement 12 - play 4 rounds
            for (int round = 0; round < NUMBER_OF_ROUNDS; round++) {
                draftRound();
                updateCompletedRegions(regions, finishedRegions);


                //TODO EUROPE ******** */
//                if (ruleSet == EUROPE) {
//                    awardPassportBonus();
//                }

                scorePlayers();
                announceCompletedRegions(finishedRegions);

                if (round < NUMBER_OF_ROUNDS - 1) {
                    prepareNextRound();
                }
            }

            calculateFinalScores();
            announceWinner();

        } catch (IllegalStateException e) {
            System.err.println("Game ended: " + e.getMessage());
        } catch (IOException e) {
            serverReady.countDown();
            System.err.println(e.getMessage());
        } finally {
            gameServer.closeConnections();
        }

    }

    private void announceWinner() {
        Player highScore = ScoreCalculator.getHighestScoringPlayer(players);

        for (Player player : players) {
            gameServer.sendMessage(player, MessageType.GAME_OVER, "The winner is player: %d with %d points"
                    .formatted(players.indexOf(highScore), highScore.getFinalScore()));
        }
    }

    private void prepareNextRound() {
        List<Card> deck = DeckFactory.createDeck(); //Requirement 11 & Requirement 2
        Collections.shuffle(deck); //Requirement 3
        //Requirement 4
        for (Player player : players) {
            player.getDraft().clear();
            player.getHand().clear();
        }
        dealCardsToPlayers(deck);
    }

    private void dealCardsToPlayers(List<Card> deck) {
        for (Player player : players) {
            for (int i = 0; i < CARDS_PER_HAND; i++) {
                player.getHand().add(deck.removeFirst());
            }
        }
    }

    private void draftRound(){
        for (int i = 0; i < DRAFTING_TURNS; i++) { //Requirement 8
            executeDraftingTurn(i);
            updatePlayerHands();

            // Requirement 5 (Keep throw card hidden)
            if (i > 0) {
                showDraftedCards();
            }
        }
    }


    private void executeDraftingTurn(int turn) {
        try (ExecutorService executor = Executors.newFixedThreadPool(players.size())) {
            CompletionService<Void> tasks = new ExecutorCompletionService<>(executor);

            // Let all players draft simultaneously.
            for (int p = 0; p < players.size(); p++) {
                Player player = players.get(p);
                Player receiver = getReceivingPlayer(p, turn);

                tasks.submit(() -> addCardToDraft(player, receiver), null);
            }

            waitForDraftingTasks(tasks);
        }
    }

    private void waitForDraftingTasks(CompletionService<Void> tasks) {
        try {
            // Wait for all players, detecting failures as soon as a task finishes.
            for (int i = 0; i < players.size(); i++) {
                tasks.take().get();
            }
        } catch (ExecutionException e) {
            // Close sockets to unblock other players waiting for input.
            gameServer.closeConnections();
            throw new IllegalStateException(e.getCause().getMessage(), e.getCause());
        } catch (InterruptedException e) {
            gameServer.closeConnections();
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Drafting interrupted.", e);
        }
    }

    private void updatePlayerHands() {
        for (Player player : players) {
            player.getHand().clear();
            // grab the cards passed on from the previous player
            player.getHand().addAll(player.getNextHand());
        }
    }

    private void showDraftedCards() {
        // Requirement 7 (Show cards)
        for (int i = 0; i < players.size(); i++) {
            List<Card> draft = players.get(i).getDraft();
            List<Card> visibleCards = draft.subList(1, draft.size());

            String message = "%nPlayer %d has drafted%n%s"
                    .formatted(i, GameFormatter.formatCards(visibleCards));

            players.forEach(player -> gameServer.sendMessage(player, MessageType.DISPLAY_MESSAGE, message));
        }
    }

    private Player getReceivingPlayer(int playerIndex, int turn) {
        // Requirement 6 (Pass remaining cards to the next player)
        // Requirement 9 (The final card is passed to the previous player)

        // If this isn't the last drafting turn, pass forward. Otherwise, pass backward.
        return turn < DRAFTING_TURNS -1
                ? players.get((playerIndex + 1) % players.size())
                : players.get((playerIndex - 1 + players.size()) % players.size());
    }

    private void updateCompletedRegions(List<String> regions, Set<String> finishedRegions) {
        for (String region : regions) {
            if (finishedRegions.contains(region)) {
                continue;
            }

            boolean regionComplete = false;

            for (Player player : players) {
                if (RegionChecker.isRegionComplete(region, player.getSites(), player.getDraft())) {
                    player.getCompletedRegions().add(region);
                    player.setRegionRoundScore(player.getRegionRoundScore() + 3);
                    regionComplete = true;
                }
            }

            if (regionComplete) {
                finishedRegions.add(region); //Requirement 10b(ii)
            }
        }
    }

    private void calculateFinalScores() {
        for (Player player : players) {
            player.setFinalScore(finalScore(player));
        }
    }

    private void scorePlayers() {
        for (Player player : players) {
            player.getDraft().add(player.getHand().removeFirst()); // Catch card

            gameServer.sendMessage(player, MessageType.DISPLAY_MESSAGE, """
            ********************************
            Your draft this round:
            """ + GameFormatter.formatCards(player.getDraft()) + "\n");

            scoreRound(player);
        }
    }

    private void announceCompletedRegions(Set<String> finishedRegions) {
        for (Player player : players) {
            gameServer.sendMessage(player, MessageType.DISPLAY_MESSAGE,
                    "The following regions have now been completed: " + finishedRegions);
        }
    }

    //TODO EU
//    private void awardPassportBonus() {
//        int previousWinners = 0;
//
//        for (Player player : players) {
//            if (player.getPassportBonus() > 0) {
//                previousWinners++;
//            }
//        }
//
//        int bonus = switch (previousWinners) {
//            case 0 -> 7;
//            case 1 -> 3;
//            case 2 -> 1;
//            default -> 0;
//        };
//
//        if (bonus == 0) {
//            return;
//        }
//
//        for (Player player : players) {
//            if (player.getPassportBonus() == 0 &&
//                    RegionChecker.hasVisitedAllRegions(
//                            player.getSites(),
//                            player.getDraft(),
//                            regions)) {
//
//                player.setPassportBonus(bonus);
//
//                gameServer.sendMessage(player,
//                        "Passport Bonus: " + bonus + " points");
//            }
//        }
//    }

}
